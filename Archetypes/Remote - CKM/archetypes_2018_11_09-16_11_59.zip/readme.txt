These are archetypes exported from the Clinical Knowledge Manager.
Export time: Fri Nov 09 16:11:59 CET 2018